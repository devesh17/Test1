import os
import json
from datetime import datetime
from flask import (Flask, render_template, request, redirect,
                   url_for, flash, jsonify)
from models import db, TestCase, TestPlan, TestAssignment, Tester

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL', 'sqlite:///tms.db')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-quartz-secret')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

CONFIG_DIR = os.path.join(os.path.dirname(__file__), 'config')


def load_json(filename):
    with open(os.path.join(CONFIG_DIR, filename), encoding='utf-8') as f:
        return json.load(f)


@app.context_processor
def inject_configs():
    return dict(
        tc_def=load_json('tc_definition.json'),
        env_def=load_json('test_plan_env.json'),
        logic=load_json('comparison_logic.json'),
        now=datetime.utcnow(),
        all_testers=Tester.query.order_by(Tester.name).all()
    )


# ---------------------------------------------------------------------------
# Helper: compute comparison deltas
# ---------------------------------------------------------------------------
def compute_deltas(execution_results, sw_versions, logic):
    """Return {test_version: {metric_key: {delta_pct, status, display}}}"""
    if not sw_versions or len(sw_versions) < 2:
        return {}
    ref_version = sw_versions[0]
    ref_results = execution_results.get(ref_version, {})
    metrics_cfg = logic.get('metrics', {})
    default_cfg = logic.get('default_metric', {'lower_is_better': True,
                                                'regression_threshold_pct': 5.0,
                                                'improvement_threshold_pct': 5.0})
    out = {}
    for test_ver in sw_versions[1:]:
        test_results = execution_results.get(test_ver, {})
        ver_deltas = {}
        for key, ref_val in ref_results.items():
            test_val = test_results.get(key)
            if ref_val is None or test_val is None:
                continue
            try:
                ref_f, test_f = float(ref_val), float(test_val)
                if ref_f == 0:
                    continue
                delta_pct = ((test_f - ref_f) / ref_f) * 100
                cfg = metrics_cfg.get(key, default_cfg)
                lower_is_better = cfg.get('lower_is_better', True)
                reg_thr = cfg.get('regression_threshold_pct', 5.0)
                imp_thr = cfg.get('improvement_threshold_pct', 5.0)

                if lower_is_better:
                    if delta_pct < -imp_thr:
                        status = 'improvement'
                    elif delta_pct > reg_thr:
                        status = 'regression'
                    else:
                        status = 'neutral'
                else:
                    if delta_pct > imp_thr:
                        status = 'improvement'
                    elif delta_pct < -reg_thr:
                        status = 'regression'
                    else:
                        status = 'neutral'

                sign = '+' if delta_pct >= 0 else ''
                ver_deltas[key] = {
                    'delta_pct': round(delta_pct, 2),
                    'status': status,
                    'display': f'{sign}{delta_pct:.1f}%'
                }
            except (TypeError, ValueError):
                pass
        out[test_ver] = ver_deltas
    return out


def resolve_assignment_status(assignment):
    """
    Derive PASS/FAIL from comparison results, else pending/in_progress.
    Returns: 'pending' | 'in_progress' | 'pass' | 'fail'
    """
    results = assignment.execution_results or {}
    plan = assignment.plan
    sw_versions = assignment.tc_snapshot.get('sw_versions', plan.sw_versions)

    if not results:
        return 'pending'

    has_all = all(v in results and results[v] for v in sw_versions)
    if not has_all:
        return 'in_progress'

    if len(sw_versions) < 2:
        return 'pass'

    logic = load_json('comparison_logic.json')
    deltas = compute_deltas(results, sw_versions, logic)
    for ver_deltas in deltas.values():
        for metric_delta in ver_deltas.values():
            if metric_delta.get('status') == 'regression':
                return 'fail'
    return 'pass'


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route('/')
def index():
    tc_count = TestCase.query.count()
    plan_count = TestPlan.query.count()
    assign_count = TestAssignment.query.count()
    complete_count = TestAssignment.query.filter(
        TestAssignment.status.in_(['pass', 'fail', 'complete'])).count()
    recent_plans = TestPlan.query.order_by(TestPlan.created_at.desc()).limit(5).all()
    tester_count = Tester.query.count()
    return render_template('index.html',
                           tc_count=tc_count,
                           plan_count=plan_count,
                           assign_count=assign_count,
                           complete_count=complete_count,
                           tester_count=tester_count,
                           recent_plans=recent_plans)


# ---------------------------------------------------------------------------
# Test Case Library
# ---------------------------------------------------------------------------
@app.route('/test-cases')
def tc_list():
    tcs = TestCase.query.order_by(TestCase.created_at.desc()).all()
    return render_template('test_cases/list.html', tcs=tcs)


@app.route('/test-cases/new', methods=['GET', 'POST'])
def tc_new():
    tc_def = load_json('tc_definition.json')
    if request.method == 'POST':
        s1 = tc_def['section_1_fixed'].copy()
        for key in s1:
            s1[key] = request.form.get(f's1_{key}', s1[key])

        s2 = {}
        for field in tc_def['section_2_feature_specific']:
            s2[field['key']] = request.form.get(f's2_{field["key"]}', field['default'])

        s3 = {}
        for field in tc_def['section_3_parameters']:
            raw = request.form.get(f's3_{field["key"]}', str(field['default']))
            try:
                s3[field['key']] = float(raw)
            except ValueError:
                s3[field['key']] = field['default']

        tc = TestCase(fixed_fields=s1, sec2_metadata=s2, sec3_parameters=s3)
        db.session.add(tc)
        db.session.commit()
        flash(f'Test case {s1["tc_id"]} created.', 'success')
        return redirect(url_for('tc_list'))

    return render_template('test_cases/form.html', tc=None)


@app.route('/test-cases/<int:tc_id>/edit', methods=['GET', 'POST'])
def tc_edit(tc_id):
    tc = TestCase.query.get_or_404(tc_id)
    tc_def = load_json('tc_definition.json')

    if request.method == 'POST':
        s1 = dict(tc.fixed_fields)
        for key in s1:
            s1[key] = request.form.get(f's1_{key}', s1[key])

        s2 = {}
        for field in tc_def['section_2_feature_specific']:
            s2[field['key']] = request.form.get(f's2_{field["key"]}',
                                                  tc.sec2_metadata.get(field['key'], field['default']))
        s3 = {}
        for field in tc_def['section_3_parameters']:
            raw = request.form.get(f's3_{field["key"]}',
                                   str(tc.sec3_parameters.get(field['key'], field['default'])))
            try:
                s3[field['key']] = float(raw)
            except ValueError:
                s3[field['key']] = tc.sec3_parameters.get(field['key'], field['default'])

        tc.fixed_fields = s1
        tc.sec2_metadata = s2
        tc.sec3_parameters = s3
        tc.updated_at = datetime.utcnow()
        db.session.commit()
        flash(f'Test case {s1["tc_id"]} updated.', 'success')
        return redirect(url_for('tc_list'))

    return render_template('test_cases/form.html', tc=tc)


@app.route('/test-cases/<int:tc_id>/delete', methods=['POST'])
def tc_delete(tc_id):
    tc = TestCase.query.get_or_404(tc_id)
    db.session.delete(tc)
    db.session.commit()
    flash('Test case deleted.', 'info')
    return redirect(url_for('tc_list'))


# ---------------------------------------------------------------------------
# Test Plans
# ---------------------------------------------------------------------------
@app.route('/plans')
def plan_list():
    plans = TestPlan.query.order_by(TestPlan.created_at.desc()).all()
    return render_template('plans/list.html', plans=plans)


@app.route('/plans/new', methods=['GET', 'POST'])
def plan_new():
    env_def = load_json('test_plan_env.json')
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        if not name:
            flash('Plan name is required.', 'error')
            return redirect(url_for('plan_new'))

        versions = [v.strip() for v in request.form.getlist('sw_version') if v.strip()]
        if len(versions) < 2:
            flash('At least 2 software versions required (1 reference + 1 test).', 'error')
            return redirect(url_for('plan_new'))

        env_config = {}
        for field in env_def['env_fields']:
            env_config[field['key']] = request.form.get(f'env_{field["key"]}', field['default'])

        plan = TestPlan(name=name, description=description,
                        sw_versions=versions, env_config=env_config)
        db.session.add(plan)
        db.session.commit()
        flash(f'Plan "{name}" created.', 'success')
        return redirect(url_for('plan_detail', plan_id=plan.id))

    return render_template('plans/form.html', plan=None)


@app.route('/plans/<int:plan_id>')
def plan_detail(plan_id):
    plan = TestPlan.query.get_or_404(plan_id)
    all_tcs = TestCase.query.order_by(TestCase.created_at.desc()).all()
    assigned_tc_ids = {a.tc_id for a in plan.assignments if a.tc_id}
    logic = load_json('comparison_logic.json')
    testers = Tester.query.order_by(Tester.name).all()
    return render_template('plans/detail.html', plan=plan,
                           all_tcs=all_tcs, assigned_tc_ids=assigned_tc_ids,
                           logic=logic, testers=testers)


@app.route('/plans/<int:plan_id>/assign', methods=['POST'])
def plan_assign(plan_id):
    plan = TestPlan.query.get_or_404(plan_id)
    tc_ids = request.form.getlist('tc_ids')
    if not tc_ids:
        flash('Select at least one test case.', 'error')
        return redirect(url_for('plan_detail', plan_id=plan_id))

    already_assigned = {a.tc_id for a in plan.assignments if a.tc_id}
    added = 0
    for tc_id in tc_ids:
        tid = int(tc_id)
        if tid in already_assigned:
            continue
        tc = TestCase.query.get(tid)
        if not tc:
            continue
        snapshot = tc.to_snapshot()
        snapshot['sw_versions'] = plan.sw_versions
        snapshot['env_config'] = plan.env_config
        assignment = TestAssignment(plan_id=plan.id, tc_id=tid, tc_snapshot=snapshot)
        db.session.add(assignment)
        added += 1

    db.session.commit()
    flash(f'{added} test case(s) assigned as snapshots.', 'success')
    return redirect(url_for('plan_detail', plan_id=plan_id))


@app.route('/plans/<int:plan_id>/delete', methods=['POST'])
def plan_delete(plan_id):
    plan = TestPlan.query.get_or_404(plan_id)
    db.session.delete(plan)
    db.session.commit()
    flash('Plan deleted.', 'info')
    return redirect(url_for('plan_list'))


# ---------------------------------------------------------------------------
# Global Assignments list
# ---------------------------------------------------------------------------
@app.route('/assignments')
def assignment_list():
    status_filter = request.args.get('status', '')
    plan_filter = request.args.get('plan_id', '')
    tester_filter = request.args.get('tester_id', '')

    q = TestAssignment.query.join(TestPlan)
    if status_filter:
        q = q.filter(TestAssignment.status == status_filter)
    if plan_filter:
        q = q.filter(TestAssignment.plan_id == int(plan_filter))
    if tester_filter:
        if tester_filter == 'unassigned':
            q = q.filter(TestAssignment.assigned_to.is_(None))
        else:
            q = q.filter(TestAssignment.assigned_to == int(tester_filter))

    assignments = q.order_by(TestAssignment.created_at.desc()).all()
    plans = TestPlan.query.order_by(TestPlan.name).all()
    testers = Tester.query.order_by(Tester.name).all()
    return render_template('assignments/list.html',
                           assignments=assignments, plans=plans,
                           testers=testers, status_filter=status_filter,
                           plan_filter=plan_filter, tester_filter=tester_filter)


@app.route('/assignments/new', methods=['GET', 'POST'])
def assignment_new():
    """Global 'Assign Test' flow: pick plan → pick TCs → create snapshots."""
    plans = TestPlan.query.order_by(TestPlan.name).all()
    selected_plan = None
    all_tcs = []
    assigned_tc_ids = set()

    plan_id = request.args.get('plan_id') or request.form.get('plan_id')
    if plan_id:
        selected_plan = TestPlan.query.get(int(plan_id))
        if selected_plan:
            all_tcs = TestCase.query.order_by(TestCase.created_at.desc()).all()
            assigned_tc_ids = {a.tc_id for a in selected_plan.assignments if a.tc_id}

    if request.method == 'POST' and selected_plan:
        tc_ids = request.form.getlist('tc_ids')
        tester_id = request.form.get('tester_id') or None
        tester = Tester.query.get(int(tester_id)) if tester_id else None
        already = {a.tc_id for a in selected_plan.assignments if a.tc_id}
        added = 0
        for tc_id in tc_ids:
            tid = int(tc_id)
            if tid in already:
                continue
            tc = TestCase.query.get(tid)
            if not tc:
                continue
            snapshot = tc.to_snapshot()
            snapshot['sw_versions'] = selected_plan.sw_versions
            snapshot['env_config'] = selected_plan.env_config
            a = TestAssignment(
                plan_id=selected_plan.id, tc_id=tid, tc_snapshot=snapshot,
                assigned_to=tester.id if tester else None,
                assigned_at=datetime.utcnow() if tester else None
            )
            db.session.add(a)
            added += 1

        db.session.commit()
        flash(f'{added} assignment(s) created.', 'success')
        return redirect(url_for('assignment_list'))

    testers = Tester.query.order_by(Tester.name).all()
    return render_template('assignments/new.html',
                           plans=plans, selected_plan=selected_plan,
                           all_tcs=all_tcs, assigned_tc_ids=assigned_tc_ids,
                           testers=testers)


@app.route('/assignments/<int:assign_id>/assign-user', methods=['POST'])
def assignment_assign_user(assign_id):
    assignment = TestAssignment.query.get_or_404(assign_id)
    tester_id = request.form.get('tester_id')
    if tester_id:
        tester = Tester.query.get(int(tester_id))
        assignment.assigned_to = tester.id if tester else None
        assignment.assigned_at = datetime.utcnow() if tester else None
        flash(f'Assigned to {tester.name}.' if tester else 'User assignment removed.', 'success')
    else:
        assignment.assigned_to = None
        assignment.assigned_at = None
        flash('User assignment removed.', 'info')
    db.session.commit()
    return redirect(request.referrer or url_for('assignment_list'))


# ---------------------------------------------------------------------------
# Assignment Execution
# ---------------------------------------------------------------------------
@app.route('/assignments/<int:assign_id>/execute')
def assignment_execute(assign_id):
    assignment = TestAssignment.query.get_or_404(assign_id)
    plan = assignment.plan
    logic = load_json('comparison_logic.json')
    tc_def = load_json('tc_definition.json')
    sw_versions = assignment.tc_snapshot.get('sw_versions', plan.sw_versions)
    deltas = compute_deltas(assignment.execution_results or {}, sw_versions, logic)
    testers = Tester.query.order_by(Tester.name).all()
    return render_template('assignments/execute.html',
                           assignment=assignment, plan=plan,
                           sw_versions=sw_versions, deltas=deltas,
                           logic=logic, tc_def=tc_def, testers=testers)


@app.route('/assignments/<int:assign_id>/save', methods=['POST'])
def assignment_save(assign_id):
    assignment = TestAssignment.query.get_or_404(assign_id)
    plan = assignment.plan
    sw_versions = assignment.tc_snapshot.get('sw_versions', plan.sw_versions)
    tc_def = load_json('tc_definition.json')

    results = {}
    for version in sw_versions:
        ver_results = {}
        for field in tc_def['section_3_parameters']:
            key = field['key']
            raw = request.form.get(f'result_{version}_{key}', '').strip()
            if raw:
                try:
                    ver_results[key] = float(raw)
                except ValueError:
                    pass
        if ver_results:
            results[version] = ver_results

    assignment.execution_results = results
    assignment.status = resolve_assignment_status(assignment)
    assignment.updated_at = datetime.utcnow()
    db.session.commit()
    flash('Results saved.', 'success')
    return redirect(url_for('assignment_execute', assign_id=assign_id))


@app.route('/assignments/<int:assign_id>/delete', methods=['POST'])
def assignment_delete(assign_id):
    assignment = TestAssignment.query.get_or_404(assign_id)
    plan_id = assignment.plan_id
    next_url = request.form.get('next', url_for('plan_detail', plan_id=plan_id))
    db.session.delete(assignment)
    db.session.commit()
    flash('Assignment removed.', 'info')
    return redirect(next_url)


# ---------------------------------------------------------------------------
# Team / Testers
# ---------------------------------------------------------------------------
AVATAR_COLORS = ['#6366F1', '#8B5CF6', '#EC4899', '#F59E0B',
                 '#10B981', '#3B82F6', '#EF4444', '#14B8A6']


@app.route('/users')
def user_list():
    testers = Tester.query.order_by(Tester.name).all()
    return render_template('users/list.html', testers=testers)


@app.route('/users/new', methods=['POST'])
def user_new():
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    role = request.form.get('role', 'Tester').strip()
    if not name:
        flash('Name is required.', 'error')
        return redirect(url_for('user_list'))
    color = AVATAR_COLORS[Tester.query.count() % len(AVATAR_COLORS)]
    tester = Tester(name=name, email=email or None, role=role, avatar_color=color)
    db.session.add(tester)
    db.session.commit()
    flash(f'{name} added to the team.', 'success')
    return redirect(url_for('user_list'))


@app.route('/users/<int:user_id>/delete', methods=['POST'])
def user_delete(user_id):
    tester = Tester.query.get_or_404(user_id)
    name = tester.name
    # Unlink from assignments
    for a in tester.assignments:
        a.assigned_to = None
        a.assigned_at = None
    db.session.delete(tester)
    db.session.commit()
    flash(f'{name} removed from team.', 'info')
    return redirect(url_for('user_list'))


# ---------------------------------------------------------------------------
# API: real-time delta
# ---------------------------------------------------------------------------
@app.route('/api/compute-delta', methods=['POST'])
def api_compute_delta():
    data = request.get_json(force=True)
    sw_versions = data.get('sw_versions', [])
    execution_results = data.get('execution_results', {})
    logic = load_json('comparison_logic.json')
    deltas = compute_deltas(execution_results, sw_versions, logic)
    return jsonify(deltas)


# ---------------------------------------------------------------------------
# Admin
# ---------------------------------------------------------------------------
@app.route('/admin')
def admin_index():
    tc_count = TestCase.query.count()
    plan_count = TestPlan.query.count()
    assign_count = TestAssignment.query.count()
    tester_count = Tester.query.count()
    return render_template('admin/index.html',
                           tc_count=tc_count, plan_count=plan_count,
                           assign_count=assign_count, tester_count=tester_count)


@app.route('/admin/seed', methods=['POST'])
def admin_seed():
    tc_def = load_json('tc_definition.json')
    env_def = load_json('test_plan_env.json')

    # Seed testers
    tester_data = [
        ('Alice Chen',   'alice@quartz.dev',  'Lead',   '#6366F1'),
        ('Bob Patel',    'bob@quartz.dev',    'Tester', '#10B981'),
        ('Carol Kim',    'carol@quartz.dev',  'Tester', '#F59E0B'),
        ('David Osei',   'david@quartz.dev',  'Tester', '#EF4444'),
    ]
    testers = []
    for name, email, role, color in tester_data:
        t = Tester(name=name, email=email, role=role, avatar_color=color)
        db.session.add(t)
        testers.append(t)
    db.session.flush()

    # Seed 5 test cases
    groups = ['COMPUTE', 'MEMORY', 'NETWORK', 'STORAGE', 'GPU']
    modules = ['Encode', 'Decode', 'Transfer', 'Compress', 'Render']
    features = ['Fast_Path', 'Slow_Path', 'Batch_Mode', 'Stream_Mode', 'Parallel_Exec']
    instr = ['AVX512_DUMMY', 'AVX2_DUMMY', 'SSE4_DUMMY', 'NEON_DUMMY', 'GENERIC_DUMMY']
    flags = ['-O3_DUMMY', '-O2_DUMMY', '-O1_DUMMY', '-Os_DUMMY', '-Og_DUMMY']

    tcs = []
    for i in range(1, 6):
        tc = TestCase(
            fixed_fields={'tc_id': f'TC_DUMMY_{i:03d}', 'group': groups[i-1],
                          'module': modules[i-1], 'feature': features[i-1]},
            sec2_metadata={'instruction_set': instr[i-1], 'compiler_flags': flags[i-1],
                           'cache_mode': f'CACHE_MODE_{i}_DUMMY', 'thread_count': f'{i*2}T_DUMMY'},
            sec3_parameters={'target_latency': round(10.0 + i*2.5, 1),
                             'mem_bw': round(20.0 + i*5.0, 1),
                             'throughput_threshold': round(800.0 + i*100.0, 1),
                             'cpu_utilization': round(60.0 + i*5.0, 1)}
        )
        db.session.add(tc)
        tcs.append(tc)
    db.session.flush()

    env_config = {f['key']: f['default'] for f in env_def['env_fields']}

    # Seed 3 plans with varying assignments
    plans_data = [
        ('A0 Silicon Validation',    ['Ref_v1.0_DUMMY', 'Test_v2.0_DUMMY'],  tcs[:2]),
        ('B0 Performance Regression',['Ref_v1.0_DUMMY', 'Test_v2.0_DUMMY'],  tcs[2:4]),
        ('C0 Power Budget Verification',['Baseline_DUMMY', 'Target_DUMMY'],   tcs[4:5]),
    ]
    statuses = [['pass','pass'], ['fail','pending'], ['fail']]

    for idx, (pname, versions, plan_tcs) in enumerate(plans_data):
        plan = TestPlan(name=pname, description=f'Auto-seeded plan {idx+1}.',
                        sw_versions=versions, env_config=env_config)
        db.session.add(plan)
        db.session.flush()
        for j, tc in enumerate(plan_tcs):
            snapshot = tc.to_snapshot()
            snapshot['sw_versions'] = versions
            snapshot['env_config'] = env_config
            tester = testers[j % len(testers)]
            st = statuses[idx][j] if j < len(statuses[idx]) else 'pending'
            a = TestAssignment(
                plan_id=plan.id, tc_id=tc.id, tc_snapshot=snapshot,
                status=st,
                assigned_to=tester.id,
                assigned_at=datetime.utcnow()
            )
            db.session.add(a)

    db.session.commit()
    flash('Seeded 4 testers, 5 test cases, 3 plans, and 5 assignments.', 'success')
    return redirect(url_for('admin_index'))


@app.route('/admin/reset', methods=['POST'])
def admin_reset():
    db.drop_all()
    db.create_all()
    flash('Database reset. All tables dropped and recreated.', 'info')
    return redirect(url_for('admin_index'))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)
