from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class Tester(db.Model):
    __tablename__ = 'tester'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(200), nullable=True)
    role = db.Column(db.String(50), default='Tester')   # Tester | Lead | Admin
    avatar_color = db.Column(db.String(20), default='#6366F1')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    assignments = db.relationship('TestAssignment', backref='assignee', lazy=True,
                                  foreign_keys='TestAssignment.assigned_to')

    @property
    def initials(self):
        parts = self.name.strip().split()
        if len(parts) >= 2:
            return (parts[0][0] + parts[-1][0]).upper()
        return self.name[:2].upper()

    def __repr__(self):
        return f'<Tester {self.name}>'


class TestCase(db.Model):
    __tablename__ = 'test_case'

    id = db.Column(db.Integer, primary_key=True)
    fixed_fields = db.Column(db.JSON, nullable=False)       # Section 1
    sec2_metadata = db.Column(db.JSON, nullable=False)      # Section 2
    sec3_parameters = db.Column(db.JSON, nullable=False)    # Section 3
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    assignments = db.relationship('TestAssignment', backref='source_tc', lazy=True,
                                  foreign_keys='TestAssignment.tc_id')

    def to_snapshot(self):
        return {
            'source_tc_id': self.id,
            'fixed_fields': dict(self.fixed_fields),
            'sec2_metadata': dict(self.sec2_metadata),
            'sec3_parameters': dict(self.sec3_parameters),
            'snapshotted_at': datetime.utcnow().isoformat()
        }

    def __repr__(self):
        return f'<TestCase {self.fixed_fields.get("tc_id", self.id)}>'


class TestPlan(db.Model):
    __tablename__ = 'test_plan'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    sw_versions = db.Column(db.JSON, nullable=False)
    env_config = db.Column(db.JSON, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    assignments = db.relationship('TestAssignment', backref='plan', lazy=True,
                                  cascade='all, delete-orphan')

    @property
    def reference_version(self):
        return self.sw_versions[0] if self.sw_versions else None

    @property
    def test_versions(self):
        return self.sw_versions[1:] if len(self.sw_versions) > 1 else []

    @property
    def completion_pct(self):
        if not self.assignments:
            return 0
        done = sum(1 for a in self.assignments if a.status in ('complete', 'pass', 'fail'))
        return int((done / len(self.assignments)) * 100)

    def __repr__(self):
        return f'<TestPlan {self.name}>'


class TestAssignment(db.Model):
    __tablename__ = 'test_assignment'

    id = db.Column(db.Integer, primary_key=True)
    plan_id = db.Column(db.Integer, db.ForeignKey('test_plan.id'), nullable=False)
    tc_id = db.Column(db.Integer, db.ForeignKey('test_case.id'), nullable=True)

    # Immutable snapshot
    tc_snapshot = db.Column(db.JSON, nullable=False)

    # Results: {"Ref_v1.0": {"target_latency": 50.0, ...}, ...}
    execution_results = db.Column(db.JSON, nullable=True, default=dict)

    # pending | in_progress | complete | pass | fail
    status = db.Column(db.String(50), default='pending', nullable=False)

    # User assignment
    assigned_to = db.Column(db.Integer, db.ForeignKey('tester.id'), nullable=True)
    assigned_at = db.Column(db.DateTime, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @property
    def ta_id(self):
        """Human-readable assignment ID."""
        return f'TA-{self.id:04d}'

    @property
    def display_status(self):
        """Normalize status for display."""
        mapping = {
            'pending':     'PENDING',
            'in_progress': 'IN PROGRESS',
            'complete':    'COMPLETE',
            'pass':        'PASS',
            'fail':        'FAIL',
        }
        return mapping.get(self.status, self.status.upper())

    def __repr__(self):
        return f'<TestAssignment {self.ta_id}>'
